a = int(input())
if a<=5:
    for f in range(0,a):
        triangle = 11**f
        triangle = str(triangle).replace(""," ")
        print(" "*(a-f-1) + triangle)